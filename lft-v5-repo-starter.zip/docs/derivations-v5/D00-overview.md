# D00 – Overview

These files contain the full derivations backing the theory-v5 prose. Symbols follow the glossary.
