# D07 – Composition and Tensoring

Independent systems \(A,B\) require order-independence and scalar commutativity (A7).
This fixes how tensor products are formed and helps exclude \(\mathbb{H}\) in D02.
