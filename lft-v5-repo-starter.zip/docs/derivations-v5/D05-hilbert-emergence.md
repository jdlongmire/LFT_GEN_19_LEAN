# D05 – Hilbert Emergence

Basis \(|[G]\rangle\) for \(G\in\mathcal{A}\) with \(\langle [G]|[H]\rangle=\delta_{GH}\).
Completion ⇒ \(\mathcal{H} \cong \ell^2(\mathcal{A},\mathbb{C})\).

Notes on separability (A1), positivity, and conjugation come from the diagonal kernel and countable basis.
