# D04 – Born Rule via Gleason/Busch

**Assumptions used:** A5.

For \(\dim \mathcal{H} \ge 3\): unique density operator \(\rho\) with \(\mu(P)=\mathrm{Tr}(\rho P)\).
For 2D sectors: add POVM noncontextuality or continuity (Busch). Pure states ⇒ \(|\langle i|\psi\rangle|^2\).
