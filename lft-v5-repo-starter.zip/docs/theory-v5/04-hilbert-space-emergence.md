# 04 – Hilbert Space Emergence

State basis: \(|[G]\rangle\) for \(G\in\mathcal{A}\), orthonormal by logical distinguishability.
Completion: \(\mathcal{H} \cong \ell^2(\mathcal{A},\mathbb{C})\).

Notes:
- Complex field is established in the derivations folder (D02).
- This section stays conceptual; proofs live in D05.
