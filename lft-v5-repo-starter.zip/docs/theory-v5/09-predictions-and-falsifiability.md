# 09 – Predictions and Falsifiability

- Small deviations in specific regimes (order \(10^{-6}\))
- Timing/decoherence dependencies via \(D\)

Protocols are documented in your prior drafts; migrate them here as you finalize.
