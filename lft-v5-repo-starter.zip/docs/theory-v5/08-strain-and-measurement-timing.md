# 08 – Strain and Measurement Timing

Define strain \(D: \mathcal{A} \to \mathbb{R}_{\ge 0}\). Use \(D\) only for **when** a resolution occurs.
Outcome weights remain from \(\mu\) (Born rule).

Details in [/docs/derivations-v5/D06-strain-timing-policy.md](../derivations-v5/D06-strain-timing-policy.md).
