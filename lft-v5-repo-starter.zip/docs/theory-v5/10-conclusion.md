# 10 – Conclusion

LFT v5 derives the complex Hilbert space, unitary dynamics, and Born rule from 3FLL
plus explicit representation and composition axioms. Strain governs timing; probabilities
remain uniquely fixed by the valuation axioms.
